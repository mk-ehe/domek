import time
import sys
import os

start_time = time.time()

lista_wrong = []

def check_snow_out(path_in, path_out):

    lista_list = []     
    lista_check = []
    
    def display_house():
        for play in lista_list:
            for dis in play:
                print(dis,end='')
            print()

    with open(path_in) as base_house:
        
        next(base_house)

        for i in base_house.readlines():
            lista_list.append(list(i.strip()))


        with open(path_out) as complex:
            for i in complex.readlines():
                lista_check.append(list(i.strip()))


        changed = True
        while changed:
            changed = False
            for i in range(len(lista_list) - 1):
                for j in range(len(lista_list[0])):
                    if lista_list[i][j] == '*' and lista_list[i + 1][j] == '.':
                        lista_list[i][j] = '.'
                        lista_list[i + 1][j] = '*'
                        changed = True
                        # display_house()
                        # time.sleep(0.07)


    # original_out = sys.stdout
    # sys.stdout = open('learning\\domki\\output_check.txt','w')
    # display_house()
    # sys.stdout = original_out


    print('Comparing outputs...')

    if lista_check == lista_list:
        print('Files are matching.')
    else:
        lista_wrong.append(path_out[25:])
        print('Files are not the same, the provided output is different.')


for filename in os.listdir("learning\\domki\\dom_testy"):

    if filename.endswith(".in"):
        path_to_check_in = f'learning\\domki\\dom_testy\\{filename}'

    if filename.endswith(".out"):
        path_to_check_out = f'learning\\domki\\dom_testy\\{filename}'

        check_snow_out(path_to_check_in,path_to_check_out)


if len(lista_wrong) != 0:
    print('There is something wrong with these files: ')
    for i in lista_wrong:
        print(f'{i}/in')

end_time = time.time()

elapsed_time = end_time - start_time
print(f"Program execution time: {elapsed_time:.2f} seconds.")